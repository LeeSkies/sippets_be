const mongoose = require('mongoose')
const bcrypt = require('bcrypt')

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        trim: true,
    },
    email: {
        type: String,
        required: true,
        match: /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/,
        unique: true,
        trim: true,
    },
    password: {
        type: String,
        required: true
    },
    refreshToken: {
        type: String,
        required: false
    }
}, {timestamps: true})

userSchema.methods.comparePassword = (password) => {
    return bcrypt.compareSync(password, this.password)
}

module.exports = mongoose.model('User', userSchema)