const mongoose = require('mongoose');
const { signupValidation, loginValidation } = require('../inputValidations/userValidations');
const { signup, login, stayLoggedIn } = require('../controllers/userControllers');

const router = mongoose.Router()

router.get('/signup', signupValidation, signup)

router.get('/login', loginValidation, login)

router.get('/refresh', stayLoggedIn)

module.exports = router;