const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')
require('dotenv').config()

const User = require('../models/userModel')

const signup = async (req, res) => {
  const { username, email, password: p } = req.body
  try {
    
    const password = bcrypt.hashSync(p, 10);
    await User.create({username, email, password})
    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    res.status(500).json({ message: 'An error occurred while creating the user', error: error.message });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email: email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    if (!await user.comparePassword(password)) {
      return res.status(401).json({ message: 'Invalid password' });
    }

    const token = jwt.sign(
      { email: user.email, username: user.username, id: user._id },
      process.env.CHIPS,{expiresIn: 900}
    );  

    const refreshToken = jwt.sign(
      { email: user.email, username: user.username, id: user._id },
      process.env.REFRESH,
      { expiresIn: 2592000 }
    );
    
    // saving the refresh token
    user.refreshToken = refreshToken;
    await user.save()
    
    // setting a cookie to keep the refresh token
    res.cookie('refreshToken', refreshToken, {
        httpOnly: true,
        maxAge: 259200 * 1000,
    })

    return res.json({ token: token });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

const stayLoggedIn = async (req, res) => {
  const refreshToken = req.cookies.refreshToken;

  if (!refreshToken) {
    return res.status(401).json({ message: 'Refresh token not found' });
  }

  try {
    const decoded = jwt.verify(refreshToken, process.env.REFRESH);
    const user = await User.findById(decoded.id);

    if (!user || user.refreshToken != refreshToken) {
      return res.status(401).json({ message: 'Invalid refresh token' });
    }

    const newToken = jwt.sign(
      { email: user.email, username: user.username, id: user._id },
      process.env.CHIPS,
      { expiresIn: 900 }
    );

    return res.json({ token: newToken });
  } catch (err) {
    return res.status(401).json({ message: 'Refresh token expired or invalid' });
  }
};

module.exports = {
  signup,
  login,
  stayLoggedIn
}