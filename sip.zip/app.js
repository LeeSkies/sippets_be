const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();

// middleware
app.use(express.json())
app.use((req, res, next) => {
    console.log(req.path, req.method)
    next()
})

// routes
// app.use('/users')

// const crypto = require('crypto');
// const jwtKey = crypto.randomBytes(32).toString('hex');
// console.log(jwtKey);

const connectDB = async () => {
    await mongoose.connect(process.env.MONGO_URI)
    app.listen(process.env.PORT, () => {
        console.log("I'm merry poppins y'all")
    })
}

connectDB()
