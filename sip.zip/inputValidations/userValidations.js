const joi = require('joi')
const jwt = require('jsonwebtoken')

const signupSchema = joi.object({
    username: joi.string().min(3).max(30).required(),
    email: joi.string().email().required(),
    password: joi.string().min(3).max(30).required()
})

const loginSchema = joi.object({
    email: joi.string().email().required(),
    password: joi.string().min(3).max(30).required()
})

const signupValidation = (req, res, next) => {
    joi.validate(req.body, signupSchema, (err, value) => {
        if (err) {
            res.status(400).json({ message: err.message })
        }
    })
    next()
}

const loginValidation = (req, res, next) => {
    joi.validate(req.body, loginSchema, (err, value) => {
        if (err) {
            res.status(400).json({ message: err.message })
        }
    })
}

module.exports = {
    signupValidation,
    loginValidation
}